THIS PLUGIN IS DEPRECATED!!!
Plugins should use framework tags instead.

E.g.:
    &lt;framework src="com.google.android.gms:play-services-plus:+" /&gt;
    &lt;framework src="com.google.android.gms:play-services-identity:+" />&gt;

Full list available: http://developer.android.com/google/play-services/setup.html
